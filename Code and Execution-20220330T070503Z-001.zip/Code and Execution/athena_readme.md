Pre-requsites for AWS athena
----------------------------
1. Intermediate knowledge in SQL
2. Basic knowledge in AWS


Topics covered in Athena
1. Table creations
	a. Using glue Crawler
	b. Using CTAS
	c. USIng DDL
2. Athena Partitioning
3. Athena Bucketing
4. Athena Optimizations
5. Athena Workgroup


Reference documents
-------------------
Athena optimization: https://aws.amazon.com/blogs/big-data/top-10-performance-tuning-tips-for-amazon-athena/
Athena documentation: https://docs.aws.amazon.com/athena/latest/ug/what-is.html



Kaggle unprocessed link: https://www.kaggle.com/pavellexyr/the-reddit-covid-dataset



Query used to create both bucketed and partitioned table using CTA query
------------------------------------------------------------------------
CREATE TABLE partitioned_bucketed_parquet_table_100
WITH (
      format = 'Parquet',
      write_compression = 'SNAPPY',
	  external_location = 's3://athena-tutorial-video-demo/partitioned_data/partitioned_bucketed_parquet_table_100/',
	  partitioned_by = ARRAY['year', 'created_month'],
	  bucketed_by = ARRAY['id'], 
      bucket_count = 100
	  ) as
SELECT 
type  , 
  id  , 
  "subreddit.id"  , 
  "subreddit.name"  , 
  "subreddit.nsfw"  , 
  created_utc  , 
  permalink  , 
  body  , 
   sentiment  , 
  score , 
  year,
  month(created_utc_date) as created_month

 FROM "athena_reddit_covid_dataset"."json_formatted_covid_dataset" where year = 2021 and month(created_utc_date) = 8


----------------------------------------------------------------------------------------------------------------------

CREATE EXTERNAL TABLE IF NOT EXISTS json_formatted_covid_dataset (
    `type` string , 
  `id` string , 
  `subreddit.id` string , 
  `subreddit.name` string , 
  `subreddit.nsfw` string , 
  `created_utc` string , 
  `permalink` string , 
  `body` string , 
  `sentiment` string , 
  `score` string , 
  `created_utc_date` date , 
  `year` int 
) ROW FORMAT SERDE 'org.apache.hive.hcatalog.data.JsonSerDe'
 LOCATION 's3://athena-tutorial-video-demo/formatted/json_formatted_dataset/';